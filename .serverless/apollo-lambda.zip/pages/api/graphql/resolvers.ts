export {};

export const resolvers = {
  Query: {
    // insert queries
  },
};
